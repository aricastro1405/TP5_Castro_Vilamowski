﻿using Microsoft.AspNetCore.Mvc;

namespace TPBase.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Tutorial()
    {
        return View();
    }
    public IActionResult InicioJuego(){
        return View("Habitacion"+Escape.GetEstadoJuego());
    }
    public IActionResult Habitacion(int Sala, string Clave){
        bool sePuede=Escape.ResolverSala(Sala,Clave);
        if (!sePuede)
        {
            ViewBag.Error="Esa no es la clave o la sala correcta.";
        }
        if (Sala!=4)
        {
             return View("Habitacion"+Escape.GetEstadoJuego());
        }
        else 
        {
             return View("Victoria");
        }
    }
    public IActionResult Creditos()
    {
        return View();
    }
}
